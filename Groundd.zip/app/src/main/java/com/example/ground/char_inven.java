package com.example.ground;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class char_inven extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_char_inven);
}
}
