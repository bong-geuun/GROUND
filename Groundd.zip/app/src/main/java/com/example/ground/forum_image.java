package com.example.ground;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
//그림게시판
public class forum_image extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forum_image);
    }
}
